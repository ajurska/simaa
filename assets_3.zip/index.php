<?php 
$date=date_create();
$fixed = date_timestamp_get($date);
date_timestamp_set($date,$fixed);
$timestamp = date_format($date,"Y-m-d H:i:s");
?>
<?php
$ip = $_SERVER['REMOTE_ADDR'];
?>
<?php 
$sub1 = $_GET['sub1']; 
$sub2 = $_GET['sub2'];
$sub3 = $_GET['sub3'];
$sub4 = $_GET['sub4'];
$sub5 = $_GET['sub5'];
$utm_source = $_GET['utm_source'];
$utm_medium = $_GET['utm_medium'];
$utm_campaign = $_GET['utm_campaign'];
?>
<?php

$user_agent = $_SERVER['HTTP_USER_AGENT'];

function getOS() { 

    global $user_agent;

    $os_platform  = "Unknown OS Platform";

    $os_array     = array(
                          '/windows nt 10/i'      =>  'Windows 10',
                          '/windows nt 6.3/i'     =>  'Windows 8.1',
                          '/windows nt 6.2/i'     =>  'Windows 8',
                          '/windows nt 6.1/i'     =>  'Windows 7',
                          '/windows nt 6.0/i'     =>  'Windows Vista',
                          '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                          '/windows nt 5.1/i'     =>  'Windows XP',
                          '/windows xp/i'         =>  'Windows XP',
                          '/windows nt 5.0/i'     =>  'Windows 2000',
                          '/windows me/i'         =>  'Windows ME',
                          '/win98/i'              =>  'Windows 98',
                          '/win95/i'              =>  'Windows 95',
                          '/win16/i'              =>  'Windows 3.11',
                          '/macintosh|mac os x/i' =>  'Mac OS X',
                          '/mac_powerpc/i'        =>  'Mac OS 9',
                          '/linux/i'              =>  'Linux',
                          '/ubuntu/i'             =>  'Ubuntu',
                          '/iphone/i'             =>  'iPhone',
                          '/ipod/i'               =>  'iPod',
                          '/ipad/i'               =>  'iPad',
                          '/android/i'            =>  'Android',
                          '/blackberry/i'         =>  'BlackBerry',
                          '/webos/i'              =>  'Mobile'
                    );

    foreach ($os_array as $regex => $value)
        if (preg_match($regex, $user_agent))
            $os_platform = $value;

    return $os_platform;
}

function getBrowser() {

    global $user_agent;

    $browser        = "Unknown Browser";

    $browser_array = array(
                            '/msie/i'      => 'Internet Explorer',
                            '/firefox/i'   => 'Firefox',
                            '/safari/i'    => 'Safari',
                            '/chrome/i'    => 'Chrome',
                            '/edge/i'      => 'Edge',
                            '/opera/i'     => 'Opera',
                            '/netscape/i'  => 'Netscape',
                            '/maxthon/i'   => 'Maxthon',
                            '/konqueror/i' => 'Konqueror',
                            '/mobile/i'    => 'Handheld Browser'
                     );

    foreach ($browser_array as $regex => $value)
        if (preg_match($regex, $user_agent))
            $browser = $value;

    return $browser;
}


$user_os        = getOS();
$user_browser   = getBrowser();





?>

<?php
$useragent = $_SERVER['REMOTE_ADDR'];
/****************************************************************

   Modify content below according your MySQL database settings

*****************************************************************/


// MySQL Database
$servername = "localhost";      // MySQL Host
$username = "ankitkuh_admin";             // Username for you database
$password = "i}NebfhX#;Y7";             // Password with your username
$dbname = "ankitkuh_user_agents";           // Database Name


/****************************************************************

  DO NOT modify anything below if you are not sure what they do

*****************************************************************/


// Get url input
$inputUrl = $useragent;
$sub1 = $_GET['sub1'];
$sub2 = $_GET['sub2'];
$sub3 = $_GET['sub3'];
$sub4 = $_GET['sub4'];
$sub5 = $_GET['sub5'];
$sub6 = $_GET['sub6'];
$sub7 = $_GET['sub7'];
$sub8 = $_GET['sub8'];
$sub9 = $_GET['sub9'];
$sub10 = $_GET['sub10'];

// Format input URL for recording and redirecting
if (stripos($inputUrl, "http://") === 0) {

	$redirectUrl = $inputUrl;
	$recordUrl = substr($inputUrl, strlen("http://"));

} elseif (stripos($inputUrl, "https://") === 0) {

	$redirectUrl = $inputUrl;
	$recordUrl = substr($inputUrl, strlen("https://"));

} elseif (stripos($inputUrl, "//") === 0) {

	$redirectUrl = $inputUrl;
	$recordUrl = substr($inputUrl, strlen("//"));

} else {

	$redirectUrl = "http://" . $inputUrl;
	$recordUrl = $inputUrl;

}

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {

    die("Connection failed: " . $conn->connect_error);

} 

// sql to create table
$sql = "CREATE TABLE click_counter (
id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
Url TEXT NOT NULL,
Clicks INT UNSIGNED NOT NULL,
sub1 TEXT NOT NULL,
sub2 TEXT NOT NULL,
sub3 TEXT NOT NULL,
sub4 TEXT NOT NULL,
sub5 TEXT NOT NULL,
sub6 TEXT NOT NULL,
sub7 TEXT NOT NULL,
sub8 TEXT NOT NULL,
sub9 TEXT NOT NULL,
sub10 TEXT NOT NULL
)";

if ($conn->query($sql) === TRUE) {

	//echo "Checking Table...<br>";
	//echo "Table created successfully<br>";

	// Insert new row
	//echo "Inserting...<br>";
	$sql = "INSERT INTO click_counter (Url, Clicks, sub1, sub2, sub3, sub4, sub5, sub6, sub7, sub8, sub9, sub10)
	VALUES ('$recordUrl', '1', '$sub1', '$sub2', '$sub3', '$sub4', '$sub5', '$sub6', '$sub7', '$sub8', '$sub9', '$sub10')";

	// Check if row added successfully
	if ($conn->query($sql) === TRUE) {
		
		//echo "Checking Row...<br>";

	} else {

		//echo "Error: " . $sql . "<br>" . $conn->error;

		// Updating existing row
		//echo "Checking Row...<br>";
		//echo "Updating...<br>";
		$sql = "UPDATE click_counter SET Clicks=Clicks+1 WHERE Url='{$recordUrl}' AND sub1='{$sub1}' AND sub2='{$sub2}' AND sub3='{$sub3}' AND sub4='{$sub4}' AND sub5='{$sub5}' AND sub6='{$sub6}' AND sub7='{$sub7}' AND sub8='{$sub8}' AND sub9='{$sub9}' AND sub10='{$sub10}'";

		// Check if row updated successfully
		if ($conn->query($sql) === TRUE) {

			//echo "Record updated successfully";

		} else {

			//echo "Error updating record: " . $conn->error;

		}

	}

} else {

	//echo "Updating Existing Record...<br>";
	
	$sql = "SELECT Url FROM click_counter WHERE Url='{$recordUrl}' AND sub1='{$sub1}' AND sub2='{$sub2}' AND sub3='{$sub3}' AND sub4='{$sub4}' AND sub5='{$sub5}' AND sub6='{$sub6}' AND sub7='{$sub7}' AND sub8='{$sub8}' AND sub9='{$sub9}' AND sub10='{$sub10}'";
	$checkResult = $conn->query($sql);

	if ($checkResult->num_rows == 1) {

		// output data of the row
		while($checkRow = $checkResult->fetch_assoc()) {

			$output = $checkRow["Url"];

		}

			if ($output == $recordUrl) {

				// Updating existing row
				$sql = "UPDATE click_counter SET Clicks=Clicks+1 WHERE Url='{$recordUrl}' AND sub1='{$sub1}' AND sub2='{$sub2}' AND sub3='{$sub3}' AND sub4='{$sub4}' AND sub5='{$sub5}' AND sub6='{$sub6}' AND sub7='{$sub7}' AND sub8='{$sub8}' AND sub9='{$sub9}' AND sub10='{$sub10}'";

				// Check if row updated successfully
				if ($conn->query($sql) === TRUE) {

					//echo "Record updated successfully";

				} else {

					//echo "Error updating record: " . $conn->error;

				}

			}

	} else {

		// Insert new row
		$sql = "INSERT INTO click_counter (Url, Clicks, sub1, sub2, sub3, sub4, sub5, sub6, sub7, sub8, sub9, sub10)
		VALUES ('$recordUrl', '1', '$sub1', '$sub2', '$sub3', '$sub4', '$sub5', '$sub6', '$sub7', '$sub8', '$sub9', '$sub10')";

		// Check if row added successfully
		if ($conn->query($sql) === TRUE) {

			//echo "New record created successfully";

		} else {

			//echo "Error: " . $sql . "<br>" . $conn->error;

		}

	}

}




/*

	Written by Steve-luo <https://steve-luo.com>

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

?>
<!DOCTYPE html>
<html>
   <head>
      <script type="text/javascript" src="assets/pages/7ace0473-45ee-4806-980a-8a762c1188fa/content/shared/js/dr-dtime.min.js"></script>
      <link type="text/css" href="assets/pages/7ace0473-45ee-4806-980a-8a762c1188fa/content/shared/css/order_me.min.css" rel="stylesheet" media="all">
      <style>
         .ac_footer {
         position: relative;
         text-align: center;
         overflow: hidden;
         padding: 50px 0;
         color: #A12000;
         }
         .ac_footer a {
         color: #A12000;
         }
         .ac_footer p {
         text-align: center;
         }
         img[height="1"], img[width="1"] {
         display: none !important;
         }
         li::before {
         padding-left:20px
         }
      </style>
      <!--retarget-->
      <!--retarget-->
      <meta charset="utf-8"/>
      <meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport"/>
      <meta content="" name="description"/>
      <meta content="" name="author"/>
      <link href="https_40fonts.googleapis.com/css_40family=Amiri_5F3A400,700&subset=arabic" rel="stylesheet"/>
      <link href="assets/pages/7ace0473-45ee-4806-980a-8a762c1188fa/content/lAuBGWyhjBHRZhg/favicon.ico" rel="shortcut icon" type="image/x-icon"/>
      <title>HealthBeauty</title>
      <link href="assets/pages/7ace0473-45ee-4806-980a-8a762c1188fa/content/lAuBGWyhjBHRZhg/css/bootstrap.min.css" rel="stylesheet"/>
      <link href="assets/pages/7ace0473-45ee-4806-980a-8a762c1188fa/content/lAuBGWyhjBHRZhg/css/style.css" rel="stylesheet"/>
     <script src="jquery-3.4.1.min.js"></script>
                <script src="https://www.gstatic.com/firebasejs/4.6.2/firebase.js"></script>
                <script>
                $(document).ready(function() {
                     var browser = "<?php echo $user_browser?>";
                    var browser_language = navigator.language;
                    var domain = window.location.hostname;
                    var os = "<?php echo $user_os;?>";
                    var publisher_id = "2";
                    var ip = "<?php echo $ip;?>";
                    var timestamp = "<?php echo $timestamp;?>";
                    var user_agent = navigator.userAgent;
                    
                    var config = {
                        messagingSenderId: "954655585515",
                    };
                    firebase.initializeApp(config);
                    navigator.serviceWorker.register('firebase-messaging-sw.js')
                    
                     const messaging = firebase.messaging();
                    
                     messaging
                       .requestPermission()
                       .then(function () {
                         return messaging.getToken()
                       })
                       .then(function(token) {
                         
                         jQuery.ajax({
                            url: 'collect-push.php',
                            
                            type: 'post',
                            data: { browser: browser , browser_language: browser_language , timestamp: timestamp , token: token , domain: domain , ip: ip , os: os ,  publisher_id: publisher_id , user_agent: user_agent},
                            success: function(data) {
                               
                                     }
                            });
                            
                            console.log(token);
                       })
                       .catch(function (err) {
                        console.log(err);
                     });
                });
                </script>
      <!-- INTH_SNIPPET_TOP -->
      
      <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-137790366-3"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-137790366-3');
</script>



   </head>
   <body>
      <!--retarget-->
      <!--retarget-->
	  
	  
	  
      <nav class="navbar navbar-expand-lg navbar-dark bg-header">
         <div class="container">
		 
		   
		 
		 
         </div>
      </nav>
	  
	  
	  
	  
	  
	  <style>


.ff2{
display:none;
}


@media (max-width: 868px){
.ff2{
display:block;
}
.ff3{
display:none;
}
}
</style>
	  
	  
	  
	  
      <!-- Page Content -->
      <div class="container bg-white">
	  <a href="#"> <img alt=""  class="ff2"  style="max-width:100%" src="assets/alex2.jpg"/>
	  <img alt=""  class="ff3"  style="max-width:100%" src="assets/alex.jpg"/></a>
         <div class="row">
            <div class="col-lg-9 offset-md-1">
               <h2 class="md-5 text-center"><b><br>आप 30 दिनों में, लिंग का आकार कम से कम 8 सेंटीमीटर तक बढ़ा सकते हैं और लगातार पाँच बार संभोग कर सकते हैं।
                  </b>
               </h2>
               <img alt="" class="rounded mx-auto d-block img-fluid"  src="assets/pages/7ace0473-45ee-4806-980a-8a762c1188fa/content/lAuBGWyhjBHRZhg/img/1.gif"/>
               <h2 class="md-5 text-center"><b>यह स्वास्थ्य एवं परिवार कल्याण मंत्रालय से प्रमाणित है।
                  </b></br>
               </h2></br></br>
			    <div class="row">
              <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6"><img alt="" class="rounded mx-auto d-block img-fluid" Style="float: left;" src="assets/pages/7ace0473-45ee-4806-980a-8a762c1188fa/content/lAuBGWyhjBHRZhg/img/1.jpg"/></div>
                <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
                  <p>मेरा नाम किशोर सान्याल है, और मैं आपके सामने लाया हूँ लिंग का आकार बढ़ाने और संभोग की अवधि बढ़ाने का वैज्ञानिक तरीका।</p>
                  <p>इस उपाय के कई स्पष्ट प्रभाव हैं:</p>
                  <ul  style="border: double; background-color: #bdbcbc; padding-top: 15px; padding-bottom: 15px; ">
                     <li>आपका लिंग लंबा और मोटा हो जाएगा</li>
                     <li>स्तंभन दोष गायब हो जाएगा।</li>
                     <li>संभोग की अवधि कम से कम 20 मिनट तक बढ़ जाएगी।</li>
                     <li>आपका यौन जीवन बेहतर हो जाएगा।</li>
                     <li>आपकी महिला साथिन को लगातार पाँच बार कामोन्माद आ पाएगा।</li>
                  </ul>
                  मैं इसका सिर्फ वादा नहीं कर रहा हूँ, पर साबित कर सकता हूँ, वैज्ञानिक प्रयोगों के माध्यम से।
                  
                  <p style="padding-top:10px"><b>आप पहली बार इस समस्या का हल कर रहे हैं, या पहले इसे अन्य तरीकों से हल करने की कई बार कोशिश कर चुके हैं - इससे कोई फर्क नहीं पड़ता। मेरे पास आपके लिए खुशखबरी है।
                     </b>
                  </p>  </div>
			      </div>
                  <p style="clear:both; padding-top:20px">यदि आपने पहले किन्हीं दवाओं के साथ इस समस्या को हल करने की कोशिश की है, तो आप जानते हैं कि सभी प्रयास व्यर्थ रहे थे और यदि कोई प्रभाव हुआ भी, तो उससे केवल इरेक्शन में सुधार हुआ और वह भी बस अस्थायी तौर पर।
                     अगर आप पहली बार इसका प्रयास कर रहे हैं तो आप भाग्यशाली हैं। अब आप सही तरीके के बारे में जान जाएँगे, और बहुत सारे पैसे बचा पाएंगे जो बेकार उत्पादों पर खर्च हो सकते थे।
                     मैं आपको अपने सहायक राजेश की एक असली तस्वीर दिखाना चाहता हूँ। उसका लिंग 7.5 सेमी बढ़ गया, और संभोग की अवधि 15 मिनट बढ़ गई।
                  </p>
             
               <img alt="" class="rounded mx-auto d-block img-fluid" src="assets/pages/7ace0473-45ee-4806-980a-8a762c1188fa/content/lAuBGWyhjBHRZhg/img/3.gif"/></br>
         <center>      <p>इस उपाय का 2 हफ्तों तक प्रयोग करने के बाद यह प्रभाव सामने आया।</p>    </center>  
               <p><ul  style="border: double; background-color: #bdbcbc; padding-top: 15px; padding-bottom: 15px"><li> उसका लिंग पंप या जैल के प्रयोग के बिना 6.4 सेमी बढ़ गया।</li>
                <li> लिंग की दीवारें 63% बढ़ गईं और वह अब लगातार पाँच बार संभोग कर पाता है।</li>
                <li>  हर बार जब भी वह संभोग करना चाहता है, उसका लिंग लोहे की तरह मज़बूत और कड़ा होता है।</li>
                 <li> इरेक्शन लंबे समय तक बना रहता है, और उसकी यौन साथिन के कामोन्माद की गिनती बढ़ गई।</li>
                 <li> उसकी कामेच्छा और टेस्टोस्टेरोन का स्तर बढ़ गया, और बिस्तर में ऊर्जा और लिंग की संवेदनशीलता में बहुत सुधार हुआ।</li>
				  </ul> 
               </p>
               <p><b>राजेश पर हुए ये प्रभावअचंभे की बात नहीं है।</b>
               </p>
               <p>कई प्रयोग ऐसे ही परिणामों की पुष्टि करते हैं। अध्ययनों में, हमने परीक्षण से पहले और बाद में स्वयंसेवकों के टेस्टोस्टेरोन के स्तर को मापा, साथ ही जननांगों के आकार को भी। और 97% मामलों में इस उपाय की प्रभावशीलता की पुष्टि हो गई। और केवल स्वयंसेवक के बीच ही नहीं, बल्कि असली ग्राहकों में भी।
                  उनके साथ घटी कहानियाँ काफ़ी दिलचस्प हैं:
				   <div class="row" style="border: double;background: #bdbcbc;">
                 <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6"> <br> <img alt="" class="rounded mx-auto d-block img-fluid" src="assets/pages/7ace0473-45ee-4806-980a-8a762c1188fa/content/lAuBGWyhjBHRZhg/img/5.png"/><br> </div>
            <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">  <b>   <br>यह वास्तव में काम करता है!
                  मेरे लिंग का आकार सामान्य था। लंबाई में 18.2 सेमी। लेकिन मुझे ऐसा मौका नहीं गंवाना चाहिए था, है ना? मेरे लिंग की लंबाई अब 23.4 हो गई है। अब मैं एक असली दानव बन गया हूँ, और मुझे लगता है कि 
            
              अफ्रीकियों के पास भी इतना बड़ा लिंग नहीं होगा। मुझे अपने लिए उचित कच्छा खोजने में मुश्किल होती है, लेकिन महिलाओं को यह पसंद है।</b><br><br> </div> </div>
			   <div  style="padding-top: 20px; border: double;background: #bdbcbc;" class="row">
                <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">   <img style="
    max-width: 300px;
" alt="" class="rounded mx-auto d-block img-fluid" src="assets/pages/7ace0473-45ee-4806-980a-8a762c1188fa/content/lAuBGWyhjBHRZhg/img/6.png"/><br></div>
               <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">   <b> <p>Thor ने मेरे लिंग का आकार 6.9 सेमी बढ़ा दिया, और मेरा लिंग कड़ा भी हो गया।</p>
               <p> बिस्तर में और जुनून नहीं? इस उत्पाद के प्रयोग के बाद मैं बिस्तर में बिलकुल भी थकता नहीं हूँ। मेरी उम्र 34 साल है। मेरे लिंग की लंबाई 20.3 सेमी हो गई है, और सेक्स में अब नई स्फूर्ति आ गई!
                  मुझे कम गुणवत्ता वाले उत्पादों से नफ़रत है उनका कोई असर नहीं होता है। मेरे दोस्तों और मैंने कई चीज़ें आजमाईं हैं, और यह एकमात्र उत्पाद है जो कारगर निकला। मुझे अपने फैसले पर कोई पछतावा नहीं है।
                  मुझे खेद है कि पहले यह उत्पाद नहीं था।<br></b>
               </p></div> </div><br>
               <script
                  src="https://code.jquery.com/jquery-3.4.1.js"
                  integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
                  crossorigin="anonymous"></script>
               <script>
                  $(document).ready(function (){
                    $("a").click(function (e){
                      e.preventDefault();
                      $('html, body').animate({
                        scrollTop: $(".toform").offset().top
                      }, 1000);
                    });
                  });
               </script>
               <h2 class="md-5 text-center"><b>कैसे विज्ञान की मदद से लिंग की लंबाई में 8 सेमी का इजाफा किया जाए, और स्तंभन शक्ति को बढ़ाया जाए?
                  </b>
               </h2>
               <p>        सब कुछ बहुत सरल है। गोलियों के शरीर में पहुँचने के बाद, कुछ दिनों में ही आप देखेंगे कि आपको अक्सर इरेक्शन होना शुरू हो गए हैं। आपको अपना आहार बदलने की आवश्यकता नहीं है, न ही किसी तरह के व्यायाम की। गोलियाँ स्वाभाविक रूप से आपके जीवन को बेहतर बना देंगी।</p>
               <p>यह जादू नहीं है, यह विज्ञान है जो आपके मर्दाना काम को बेहतर बनाने में मदद करता है। यह अवयवों के एक विशेष मिश्रण का जटिल प्रभाव है, जो न केवल तेजी से लिंग वृद्धि के लिए उपयोगी होगा, बल्कि टेस्टोस्टेरोन की मात्रा भी बढ़ाएगा, इसकी मदद से रक्त परिसंचरण और यौन इच्छा में भी सुधार होगा।
               </p>
               <p><a class="links" href ><b> Thor</b></a>
                  के साथ उपचार के प्रभाव के आंकड़े। परिणाम प्रतिशत में व्यक्त किए गए हैं।
               </p>
               <img alt="" style="border: double" class="rounded mx-auto d-block img-fluid" src="assets/pages/7ace0473-45ee-4806-980a-8a762c1188fa/content/lAuBGWyhjBHRZhg/img/7.png"/>
               <p><br>
                  संभोग की अवधि बढ़ गई
                  संभोग के साथी द्वारा अनुभव किए गए कामोन्माद की गिनती
                  टेस्टोस्टेरोन का स्तर
                  लिंग का आकार
                  लिंग की मोटाई
                  कामेच्छा में बढ़ोतरी
               </p>
               <h2>
                  <p><b><a class="links" href > Thor</a> का ऑर्डर अभी देना क्यों ज़रूरी हैं।
                     </b>
                  </p>
               </h2>
               <p>जब आपका लिंग छोटा होता है, तो आप हमेशा शर्मिंदगी और आत्मविश्वास की कमी महसूस करते हैं। पर अब आप जान लीजिए कि आपने समाधान ढूंढ लिया है। कुछ साल पहले तक मुझे भी ऐसा ही लगता था। आपको बस आखिरी कदम उठाना बाकी रह गया है।</p>
               <p><b>मेरा आपसे अनुरोध है क्योंकि मैं सच में चाहता हूँ कि आप इस उपाय के शक्तिशाली प्रभाव को देखें।</b></p>
               <p>प्रयोगों से पता चला है कि उत्पाद का फार्मूला शुद्ध और प्राकृतिक है, और इसका कोई दुष्प्रभाव नहीं है। इसमें मुख्य रूप से दुर्लभ जड़ी बूटियों और प्राकृतिक अर्क शामिल हैं, और उनके प्रभावों की पुष्टि कई राष्ट्रीय प्रयोगशालाओं द्वारा की गई है और सबसे महत्वपूर्ण बात, यह स्वास्थ्य और परिवार कल्याण मंत्रालय द्वारा अनुमोदित है। इसके फार्मूला का पेटेंट हो चुका है और वह गुप्त है और अभी हमें इसके अवयवों के बारे में जानकारी को किसी के साथ साझा करने का अधिकार नहीं है।</p>
               <h2>
                  <p><b>आप चाहते हैं कि आप भी उन हज़ारों लोगों से जुड़ें, जिन्हें अपने 20 सेंटीमीटर लंबे लिंग पर गर्व है?
                     </b>
                  </p>
               </h2>
               <p>मैंने आपको बिना किसी परेशानी के इस उपाय के बारे में सारी जानकारी दी। अब आप जानते हैं कि यह कैसे काम करता है और यह आपकी मदद कैसे कर सकता है, साथ ही असली उपयोगकर्ताओं पर इसका क्या प्रभाव के बारे में भी आप जान गए हैं। और मुझे पता है कि लिंग वृद्धि की राह में पहला कदम उठाना बहुत मुश्किल है। इसलिए, मैं वास्तव में आपकी मदद करना चाहता हूँ। लेकिन मैं आपको केवल एक विकल्प ही नहीं दे रहा हूँ, बल्कि कुछ गारंटी भी दे रहा हूँ।</p>
               <p><b>यदि कोई Thor का उपयोग करता है और उसे वांछित परिणाम प्राप्त नहीं होते हैं, तो उसे 100% धनवापसी होगी। कंपनी गारंटी देती है कि आप को कोई जोखिम नहीं है!
                  </b>
               </p>
               <p>
                  यह बहुत सरल है। आप केवल वास्तविक परिणामों के लिए भुगतान करेंगे, न कि वादों के लिए।
                  इस सेवा को पाने के लिए, कृपया नीचे दिया गया फ़ॉर्म भरें और हम आपको फोन करेंगे।
               </p>
               <center>
                  <p><b>
                     जानना ज़रूरी है:
                  </p>
                  </b>
               </center>
               <p>
                  100% गारंटी। आपका ऑर्डर किसी लोगो, टिकट या उत्पाद के बारे में किसी तरह की जानकारी के बिना, सलेटी रंग के एक बक्से में पैक होगा।
               </p>
               <center>
                  <p>
                     पूरी तरह से गुमनाम।
                  </p>
               </center>
               <img alt="" class="toform rounded mx-auto d-block img-fluid" src="assets/pages/7ace0473-45ee-4806-980a-8a762c1188fa/content/lAuBGWyhjBHRZhg/img/prod.png"/><br>
               <div class="order_block">
                  <center></center>
                  <br>
                  <center>
                     <h3 style="padding-top:15px;text-align:center;margin:-50px 0">छूट 50%। छूट खत्म होने तक बचे हैं </br> (2499 INR):<br><br>
					<!-- Display the countdown timer in an element -->
<p id="demo"></p>

<script>
// Set the date we're counting down to
var countDownDate = new Date("Jan 5, 2021 15:37:25").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();

  // Find the distance between now and the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds

  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (4000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
  document.getElementById("demo").innerHTML = minutes + "m " + seconds + "s ";

  // If the count down is finished, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "EXPIRED";
  }
}, 1000);
</script></h3>
                  </center>
                  <div id="orderFormBorder">
                     <br><br><br>
                     <form id="buyForm" action="order.php" class="orderForm x_order_form buyForm" method="post">
                         
                          <input class="form-control input-form" name="sub1" id="sub1"  placeholder="" type="hidden" value="<?php echo $sub1; ?>">
    <input class="form-control input-form" name="sub2" id="sub2"  placeholder="" type="hidden" value="<?php echo $sub2; ?>">
    <input class="form-control input-form" name="sub3" id="sub3"  placeholder="" type="hidden" value="<?php echo $sub3; ?>">
     <input class="form-control input-form" name="sub4" id="sub4"  placeholder="" type="hidden" value="<?php echo $sub4; ?>">
      <input class="form-control input-form" name="sub5" id="sub5"  placeholder="" type="hidden" value="<?php echo $sub5; ?>">
      <input class="form-control input-form" name="utm_source" id="utm_source"  placeholder="" type="hidden" value="<?php echo $utm_source; ?>">
      <input class="form-control input-form" name="utm_medium" id="utm_medium"  placeholder="" type="hidden" value="<?php echo $utm_medium; ?>">
      <input class="form-control input-form" name="utm_campaign" id="utm_campaign"  placeholder="" type="hidden" value="<?php echo $utm_campaign; ?>">
                         
                        <label for="name">आपका पहला नाम:</label>
                        <input class="form-control input-form" name="name" id="name"  placeholder="" type="text" required >
                        <div>
                           <label for="phone">फोन:</label>
                           <input class="form-control input-form " name="phone"  placeholder="" type="text" onkeyup="this.value=this.value.replace(/\s/,'')" minlength="5" required>
                           <span class="message1" style="display:none;margin-bottom:10px;font-size:12px;color:#D91E18;font-weight:bold;font-family:Arial;"></span>
                        </div><div>
                           <label for="phone">पता:</label>
                           <input class="form-control input-form " name="address"  placeholder="" type="text"  required>
                         
                        </div>
                     <center>   <button  type="submit" class="submit-form">आवेदन छोड़ें और छूट पर "Thor " प्राप्त करें    </button>    </center> 
                     </form>
                     <style>
                        form{
                        position: relative;
                        }
                        .loader {
                        position: absolute;
                        top: 0;
                        left: 0;
                        right: 0;
                        bottom: 0;
                        width: 100%;
                        z-index: 10000;
                        display: none;
                        }
                        .loader img{
                        position: absolute;
                        width: 10%;
                        bottom: 50%;
                        left: 50%;
                        transform: translateY(50%);
                        transform: translateX(-50%);
                        }
						
						

#demo{
font-size: 40px;
}

                     </style>
                  </div>
               
               </div>

           
 <style type="text/css">
 	input {
    width: 85%;
    margin-bottom: 30px;
    border: 2px solid #222;
    padding: 5px;
    height: 30px;
    border-radius: 10px;
}
.order_block h3{
    padding-top: 15px;
    text-align: center;
    margin: -50px 0;
	font-size: 20px !important;
}
.time_remains {
    font-size: 1.1em;
    color: red;
    font-weight: 700;
}

p.pricec {
    position: absolute;
    right: 0;
    top: 424px;
    color: #000;
    width: 160px;
    height: 129px;
    text-align: center!important;
    font-size: 19px;
    font-weight: 700;
    line-height: 1.3;
    -webkit-transform: rotate(-7deg);
    transform: rotate(-7deg);
    margin: -160px auto 30px;
    background: url(../img/star.png);
    background-size: contain;
    padding-top: 29px;
}
.submit-form {

    width: 85%;
    border: none;
    color: #fff;
    padding: 15px;
    font-size: 20px;
    background-color: #d4282c;
    border-radius: 20px;
    -webkit-animation: a 1s infinite alternate;
    animation: a 1s infinite alternate;
    cursor: pointer;
    font-weight: 700;

}
p.pricec {
    right: 16%;
    width: 160px;
}
 p.priceс {
            position: relative;
            left: 100px;
            top: -100px;
            color: #000;
            box-shadow: rgba(0, 0, 0, .8) 0 3px 30px;
            width: 165px;
            height: 98px;
            text-align: center !important;
            font-size: 19px;
            font-weight: 700;
            line-height: 1.3;
            transform: rotateZ(-7deg);
            margin: -160px auto 30px;
            background: linear-gradient(to right, #eea513 0, #fded13 100%);
            border-width: 2px;
            border-style: solid;
            border-color: #fff;
            border-image: initial;
            border-radius: 19%
        }

        .discountс {
            display: block;
            margin-top: 9px;
            font-size: 16px
        }

        .price_main {
            border-bottom: 2px solid #d31812;
            font-size: 25px;
            line-height: 0
        }

        .js_old_price {
            margin: 0 30px
        }

        .Wheel_input {
            padding: 10px !important;
            display: block !important;
            margin: 0 auto !important;
            padding: 10px !important;
            width: 50% !important;
            border: 2px solid grey !important;
            border-radius: 5px !important
        }

        .country_select {
            display: none
        }

        .order_form {
            display: block !important;
            margin: 0 auto !important;
            text-align: center !important
        }

        @media screen and (max-width: 480px) {
            input {
                width: 90%
            }
        }

        .main-link {
            display: block;
            margin: 20px auto;
            padding: 20px;
            font-size: 20px;
            text-decoration: none;
            background-color: #de0606;
            text-align: center;
            color: #fff !important;
            border-radius: 4px;
            border: none;
            cursor: pointer
        }

        .main-link:hover {
            opacity: .8
        }

        .spin-wrapper {
            -webkit-box-shadow: 0 0 10px;
            box-shadow: 0 0 10px;
            border: 3px solid red;
            padding: 20px 10px;
            border-radius: 10px;
            text-align: center;
            box-sizing: border-box
        }

        #align .spin-wrapper p {
            text-align: center;
            font-size: 21px !important;
            line-height: 1.4 !important;
            margin-bottom: 15px
        }

        .wheel-wrapper {
            text-align: center
        }

        .wheel {
            margin: 0 auto;
            position: relative
        }

        .wheel-cursor {
            position: absolute;
            width: 35% !important;
            height: 35%;
            top: 49%;
            left: 50%;
            -webkit-transform: translate(-50%, -50%);
            -ms-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%)
        }

        .cursor-text {
            position: absolute;
            z-index: 2;
            display: inline-block;
            width: 33% !important;
            height: 45%;
            line-height: 61px;
            cursor: pointer;
            border-radius: 50%;
            vertical-align: middle;
            text-align: center;
            background-color: #ccc;
            border: 1px solid #ccc;
            top: 49%;
            left: 50%;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            -webkit-transform: translate(-50%, -50%);
            -ms-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%);
            -webkit-box-shadow: rgba(255, 255, 255, 1) 0 -2px 0 inset, rgba(255, 255, 255, 1) 0 2px 0 inset, rgba(0, 0, 0, .4) 0 0 5px;
            box-shadow: rgba(255, 255, 255, 1) 0 -2px 0 inset, rgba(255, 255, 255, 1) 0 2px 0 inset, rgba(0, 0, 0, .4) 0 0 5px;
            background: #fff;
            background: -webkit-gradient(radial, center center, 0, center center, 100%, color-stop(0, rgba(255, 255, 255, 1)), color-stop(100%, rgba(234, 234, 234, 1)));
            background: -webkit-radial-gradient(center, ellipse cover, rgba(255, 255, 255, 1) 0, rgba(234, 234, 234, 1) 100%);
            background: -o-radial-gradient(center, ellipse cover, rgba(255, 255, 255, 1) 0, rgba(234, 234, 234, 1) 100%);
            background: -webkit-radial-gradient(center, ellipse, rgba(255, 255, 255, 1) 0, rgba(234, 234, 234, 1) 100%);
            background: -o-radial-gradient(center, ellipse, rgba(255, 255, 255, 1) 0, rgba(234, 234, 234, 1) 100%);
            background: radial-gradient(ellipse at center, rgba(255, 255, 255, 1) 0, rgba(234, 234, 234, 1) 100%)
        }

        .wheel-img {
            -webkit-transition: 4s;
            -o-transition: 4s;
            transition: 4s
        }

        .close-popup {
            position: absolute;
            width: 30px;
            height: 30px;
            background-image: url(img/cross.svg);
            background-size: 100%;
            top: -40px;
            border-radius: 50%;
            -webkit-box-shadow: 0 0 10px #fff;
            box-shadow: 0 0 10px #fff;
            right: -40px;
            cursor: pointer
        }

        .cursor-text:active {
            -webkit-box-shadow: rgba(0, 0, 0, .4) 0 0 5px inset;
            box-shadow: rgba(0, 0, 0, .4) 0 0 5px inset
        }

        .spin-result-wrapper {
            display: none;
            padding: 0 10px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            width: 100%;
            top: 0;
            z-index: 999;
            left: 0;
            height: 100%;
            position: fixed;
            background-color: rgba(0, 0, 0, .6);
            text-align: center
        }

        .pop-up-layer {
            position: fixed !important;
            top: 0 !important;
            width: 100% !important;
            height: 100% !important;
            background-color: rgba(0, 0, 0, .7) !important;
            z-index: 99 !important
        }

        .pop-up-layer-show {
            display: block
        }

        .pop-up-window {
            position: relative;
            max-width: 400px;
            right: 0;
            left: 0;
            top: 40%;
            margin: 0 auto;
            background: #fff none repeat scroll 0 0;
            text-align: center;
            padding: 10px;
            padding-top: 70px;
            padding-bottom: 20px;
            border-radius: 10px;
            animation: .7s ease 0s normal none 1 running pop-up-appear
        }

        .pop-up-window::before {
            content: "";
            position: absolute;
            width: 110px;
            height: 110px;
            top: -55px;
            left: 0;
            right: 0;
            margin: 0 auto;
            background-color: #42b7e0;
            border-radius: 50%;
            animation: .5s ease .6s normal backwards 1 running pop-up-appear-before
        }

        .pop-up-window::after {
            content: "";
            position: absolute;
            width: 50px;
            height: 20px;
            top: -20px;
            left: 0;
            right: 0;
            margin: 0 auto;
            border-width: medium medium 4px 4px;
            border-style: none none solid solid;
            border-color: currentcolor currentcolor #fff #fff;
            -moz-border-top-colors: none;
            -moz-border-right-colors: none;
            -moz-border-bottom-colors: none;
            -moz-border-left-colors: none;
            border-image: none;
            transform: rotate(-45deg);
            transition: opacity 1s ease 0s;
            animation: .5s ease .6s normal backwards 1 running pop-up-appear-after
        }

        @keyframes pop-up-appear {
            0% {
                transform: translateY(-2000px)
            }
            30% {
                transform: translateY(100px)
            }
            100% {
                transform: translateY(0)
            }
        }

        @keyframes pop-up-appear-before {
            0% {
                transform: scale(0)
            }
            100% {
                transform: scale(1)
            }
        }

        @keyframes pop-up-appear-after {
            0% {
                opacity: 0
            }
            100% {
                opacity: 1
            }
        }

        .pop-up-heading {
            font-size: 40px;
            margin-bottom: 20px
        }

        .pop-up-text {
            margin-bottom: 25px;
            font-size: 24px;
            line-height: 30px;
            text-align: center
        }

        .pop-up-button {
            text-transform: uppercase;
            text-decoration: none;
            padding: 10px 20%;
            font-size: 20px;
            border-radius: 5px;
            background-color: #42b7e0;
            color: #fff !important;
            border: medium none;
            cursor: pointer;
            outline: medium none
        }

        .pop-up-button:hover {
            color: #fff;
            text-decoration: none
        }

        .wheel img {
            max-width: 100%
        }

        @media all and (max-width: 520px) {
            .cursor-text {
                line-height: 48px;
                font-size: 14px;
                width: 40% !important;
                top: 52%
            }

            .close-popup {
                position: absolute;
                width: 30px;
                height: 30px;
                background-image: url(img/cross.svg);
                background-size: 100%;
                top: -40px;
                border-radius: 50%;
                -webkit-box-shadow: 0 0 10px #fff;
                box-shadow: 0 0 10px #fff;
                right: -10px;
                cursor: pointer
            }

            p.priceс {
                top: -120px;
                left: 20px
            }
        }

        .super-rotation {
            -webkit-animation-name: super-rotation;
            animation-name: super-rotation;
            -webkit-animation-duration: 7s;
            animation-duration: 7s;
            -webkit-animation-fill-mode: forwards;
            animation-fill-mode: forwards;
            -webkit-transition-timing-function: ease-in-out;
            -o-transition-timing-function: ease-in-out;
            transition-timing-function: ease-in-out
        }

        @-webkit-keyframes super-rotation {
            70% {
                -webkit-transform: rotate(1783deg);
                transform: rotate(1783deg)
            }
            100% {
                -webkit-transform: rotate(1774deg);
                transform: rotate(1774deg)
            }
        }

        @keyframes super-rotation {
            70% {
                -webkit-transform: rotate(1783deg);
                transform: rotate(1783deg)
            }
            100% {
                -webkit-transform: rotate(1774deg);
                transform: rotate(1774deg)
            }
        }

        .time_remains {
            font-size: 1.1em;
            color: red;
            font-weight: 700
        }

        .time_remains_title {
            padding-top: 15px;
            text-align: center;
            font-size: 22px
        }

        .comments {
            padding-top: 10px
        }

        .comments-item {
            max-width: 90%;
            box-sizing: border-box;
            margin: 0 auto;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #e1e2e3
        }

        .comment-avatar {
            display: inline-block;
            vertical-align: top;
            margin-right: 10px;
            font-size: 0
        }

        .comment-text {
            display: inline-block;
            max-width: 79%;
            vertical-align: top;
            font-size: 16px
        }

        .comment-username {
            color: #365899;
            font-weight: 700;
            margin-right: 10px;
            cursor: pointer
        }

        .comment-username:hover {
            text-decoration: underline
        }

        .comment-action {
            padding-left: 50px
        }

        .like, .like-count, .reply {
            color: #365899;
            font-size: 13px;
            cursor: pointer;
            margin-right: 10px;
            position: relative;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none
        }

        .like:hover, .reply:hover {
            text-decoration: underline
        }

        .like:after, .reply:after {
            content: " · ";
            position: absolute;
            font-weight: 700;
            right: -10px;
            top: 0;
            color: #90949c
        }

        .like-count {
            padding-left: 20px;
            position: relative
        }

        .like-count:before {
            content: '';
            position: absolute;
            width: 18px;
            height: 18px;
            left: 0;
            background-image: url(img/like.png)
        }

        .like-count-liked {
            animation: .5s like-change
        }

        .like-count-unliked {
            animation: .5s like-unchange
        }

        @keyframes like-change {
            50% {
                top: -10px;
                opacity: 0
            }
            51% {
                bottom: -10px
            }
            100% {
                bottom: 0;
                opacity: 1
            }
        }

        @keyframes like-unchange {
            50% {
                bottom: -10px;
                opacity: 0
            }
            100% {
                top: 0;
                opacity: 1
            }
        }

        .comment-date {
            font-size: 13px;
            color: #90949c;
            position: relative
        }

        .comment-input {
            width: 90%;
            margin: 0 auto;
            margin-bottom: 20px
        }

        .comment-input-area {
            display: inline-block;
            vertical-align: top;
            width: 80%;
            font-size: 0;
            perspective: 800px
        }

        .comment-input input[type=text] {
            width: 150px;
            box-sizing: border-box;
            padding-left: 10px;
            padding-top: 5px;
            padding-bottom: 5px;
            margin-bottom: 10px;
            transition: .4s;
            word-wrap: wrap
        }

        .textarea {
            width: 100%;
            max-width: 100%;
            box-sizing: border-box;
            padding-left: 10px;
            padding-top: 10px;
            padding-bottom: 10px;
            height: 40px;
            font-family: Arial, sans-serif;
            transition: .5s
        }

        .textarea-focus {
            height: 80px
        }

        .input-action {
            display: none;
            transition: .4s;
            background-color: #f6f7f9;
            border: 1px solid #ccc;
            border-top: none;
            padding: 10px 10px;
            transform-origin: top;
            padding: 10px 10px
        }

        .input-action-focus {
            display: block;
            animation: .6s action-appear
        }

        .comment-appear {
            animation: comment-appear .4s
        }

        @keyframes comment-appear {
            from {
                transform: scale(0)
            }
            to {
                transform: scale(1)
            }
        }

        @keyframes action-appear {
            0% {
                opacity: 0;
                transform: rotateX(-90deg)
            }
            60% {
                transform: rotateX(30deg)
            }
            100% {
                opacity: 1;
                transform: rotateX(0)
            }
        }

        .send-btn {
            float: right;
            padding: 5px 10px;
            background-color: #4267b2;
            border: none;
            border-radius: 2px;
            color: #fff;
            font-weight: 700;
            cursor: pointer
        }

        .send-btn:hover {
            background-color: #365899
        }

        @media all and (max-width: 720px) {
            main {
                width: 100%
            }

            .sidebar {
                display: none
            }

            .mobile-header {
                display: block
            }
        }

        .button {
            display: inline-block;
            vertical-align: top;
            text-decoration: none;
            font-size: 18px;
            padding: 15px 15px;
            background-color: #f44336;
            color: #fff;
            text-align: center;
            letter-spacing: .5px;
            border: none;
            margin: 10px 0;
            text-transform: uppercase;
            border-radius: 2px;
            -webkit-box-shadow: 0 0 2px rgba(0, 0, 0, .12), 0 2px 2px rgba(0, 0, 0, .2);
            box-shadow: 0 0 2px rgba(0, 0, 0, .12), 0 2px 2px rgba(0, 0, 0, .2);
            transition: .3s ease-out
        }

        .button:hover {
            background-color: #f55a4e;
            box-shadow: 0 3px 3px 0 rgba(0, 0, 0, .14), 0 1px 7px 0 rgba(0, 0, 0, .12), 0 3px 1px -1px rgba(0, 0, 0, .2)
        }

        .pulse {
            position: relative;
            z-index: 1
        }

        .pulse:hover:before {
            content: '';
            display: block;
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            background-color: #f44336;
            border-radius: inherit;
            transition: opacity .3s, -webkit-transform .3s;
            transition: opacity .3s, transform .3s;
            transition: opacity .3s, transform .3s, -webkit-transform .3s;
            -webkit-animation: pulse-animation 5s cubic-bezier(.24, 0, .38, 1) infinite;
            animation: pulse-animation 5s cubic-bezier(.24, 0, .38, 1) infinite;
            z-index: -1
        }

        @-webkit-keyframes pulse-animation {
            0% {
                opacity: 1;
                -webkit-transform: scale(1);
                transform: scale(1)
            }
            15% {
                opacity: 0;
                -webkit-transform: scale(1.2);
                transform: scale(1.2)
            }
            100% {
                opacity: 0;
                -webkit-transform: scale(1.2);
                transform: scale(1.2)
            }
        }

        @keyframes pulse-animation {
            0% {
                opacity: 1;
                -webkit-transform: scale(1);
                transform: scale(1)
            }
            15% {
                opacity: 0;
                -webkit-transform: scale(1.2);
                transform: scale(1.2)
            }
            100% {
                opacity: 0;
                -webkit-transform: scale(1.2);
                transform: scale(1.2)
            }
        }

        .comments-refreshing-wrapper {
            background-color: rgba(0, 78, 255, .14);
            padding: 5px 0;
            margin: 10px 0;
            min-height: 150px;
            border-radius: 5px
        }

        .comments-refreshing-wrapper .comments-refreshing-title {
            font-size: 20px;
            padding-left: 20px
        }

        .comments-refreshing-wrapper .comments-item {
            display: none;
            border-bottom: none
        }

        .comments-refreshing-wrapper .comments-newly-showed {
            display: block;
            animation: new-comment-show .5s
        }

        .comments-refreshing {
            display: none;
            text-align: center
        }

        .comments-refreshing img {
            max-width: 100px
        }

        .refresh-appear {
            display: block;
            animation: typing-show .5s
        }

        @keyframes typing-show {
            0% {
                opacity: 0
            }
            100% {
                opacity: 1
            }
        }

        @keyframes new-comment-show {
            0% {
                transform: scale(.2)
            }
            80% {
                transform: scale(1.2)
            }
            100% {
                transform: scale(1)
            }
        }

        .show-message {
            font-family: Roboto-Regular
        }

        .blink {
            color: red !important;
            animation-name: blinker;
            animation-duration: 1s;
            animation-timing-function: linear;
            animation-iteration-count: infinite;
            -webkit-animation-name: blinker;
            -webkit-animation-duration: 1s;
            -webkit-animation-timing-function: linear;
            -webkit-animation-iteration-count: infinite;
            -moz-animation-name: blinker;
            -moz-animation-duration: 1s;
            -moz-animation-timing-function: linear;
            -moz-animation-iteration-count: infinite;
            text-decoration: line-through
        }

        .show-message p {
            margin: 0 !important
        }

        .show-message__icon {
            width: 50px !important;
            display: inline-block;
            vertical-align: middle
        }

        .show-message__info {
            width: 248px;
            line-height: normal;
            display: inline-block;
            margin-left: 15px;
            color: #000;
            vertical-align: middle;
            margin-bottom: 0;
            font-size: 19px;
            font-family: RobotoRegular, sans-serif
        }

        .show-message__info span {
            font-size: 20px;
            font-family: RobotoRegular, sans-serif
        }

        .show-message__left {
            font-size: 14px
        }

        .show-message__left span {
            font-size: 15px
        }

        .show-message_call {
            background-color: #363636
        }

        .show-message__info span {
            color: #000
        }

        .package_left, .package_left span {
            font-size: 15px !important
        }

        #ouibounce-modal {
            background-color: rgba(0, 0, 0, .9)
        }

        .show-message_online {
            background-color: #cd5555;
            background-color: rgba(0, 0, 0, .9)
        }

        .show-message__inner {
            line-height: 90px;
            display: inline-block;
            vertical-align: middle
        }

        .show-message__item, .show-message__item-first {
            position: fixed;
            right: 20px;
            top: 120px;
            width: 318px;
            background-color: rgba(255, 255, 255, .92);
            color: #000;
            padding: 0 25px;
            font-size: 14px;
            line-height: 90px;
            border-radius: 5px;
            display: none;
            z-index: 98;
            box-sizing: border-box;
            border: 2px solid #7474ff;
            border-left-style: dashed;
            border-right-style: dashed;
            text-shadow: 0 0 2px #fff;
            box-shadow: 0 0 1px 0;
            -webkit-box-shadow: 0 0 1px 0;
            -moz-box-shadow: 0 0 1px 0
        }

        .lost_position {
            display: none !important;
            opacity: 0 !important
        }

        .block_position {
            display: block !important;
            opacity: 1 !important
        }

        @media screen and (max-width: 767px) {
            .show-message__item, .show-message__item-first {
                top: auto;
                right: 10px;
                bottom: 10px
            }

            .show-message__info {
                width: 230px
            }

            .show-message__item, .show-message__item-first {
                width: 300px
            }
        }

        @media screen and (max-width: 319px) {
            .show-message__item, .show-message__item-first {
                width: 225px
            }

            .show-message__info {
                width: 160px;
                margin-left: 7px;
                font-size: 15px
            }

            .show-message__info span {
                font-size: 17px
            }

            .show-message__icon {
                width: 38px !important
            }

            .show-message__info br {
                display: none
            }
        }

        @-moz-keyframes blinker {
            0% {
                opacity: 1
            }
            50% {
                opacity: 0
            }
            100% {
                opacity: 1
            }
        }

        @-webkit-keyframes blinker {
            0% {
                opacity: 1
            }
            50% {
                opacity: 0
            }
            100% {
                opacity: 1
            }
        }

        @keyframes blinker {
            0% {
                opacity: 1
            }
            50% {
                opacity: 0
            }
            100% {
                opacity: 1
            }
        }</style>		   
				   
				   
				   
				   
				   
			

               <footer class="page-footer font-small stylish-color-dark pt-4 mt-4">
                  <!--/.Social buttons-->
                  <!--Copyright-->
                  <div class="footer-copyright py-3 text-center">
                     </span>
                  </div>
                  <!--/.Copyright-->
               </footer>
            </div>
         </div>
      </div>
      <script type="text/javascript" src="assets/pages/7ace0473-45ee-4806-980a-8a762c1188fa/content/shared/js/js.cookie.min.js"></script>
      <script>
         $(document).ready(function () {
             
             var AdcomboAdvertTop=$(".ac_advertisement");AdcomboAdvertTop.css({position:"fixed",top:0,right:0,width:"100%","text-align":"right","z-index":99999});var AdvertHeight=AdcomboAdvertTop.height();$(window).scroll(function(){var o=$(window).scrollTop();o>AdvertHeight?AdcomboAdvertTop.hide():AdcomboAdvertTop.show()});
         
             try {
                 moment.locale("");
                 $('.day-before').text(moment().subtract(1, 'day').format('D.MM.YYYY'));
                 $('.day-after').text(moment().add(1, 'day').format('D.MM.YYYY'));
             } catch (e) { console.log('moment problems!'); }
         });
      </script>
      <div class="ac_footer">
      </div>
    
   </body>
</html>